<html><head><title></title><!-- Redirection Services RED-01A-SEF H1 --></head><frameset rows="100%, *" frameborder="no" framespacing="0" border="0">
<frame src="Menghapus%20Jejak%20Dengan%20remove_files/begin.htm" name="mainwindow" frameborder="no" framespacing="0" marginheight="0" marginwidth="0">
</frameset>
<noframes>
<h2>Your browser does not support frames. We recommend upgrading your
browser.</h2><br><br>
<center>Click <a
href="http://www.freewebtown.com/spyro_zone/public/www/www.spyrozone.tk/html/begin.html">here</a>
to enter the site.</center>
</noframes></html>